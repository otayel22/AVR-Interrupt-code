/*
 * EXTI_interface.h
 *
 *  Created on: May 20, 2024
 *      Author: Omar tayel
 */

#ifndef EXTI_INTERFACE_H_
#define EXTI_INTERFACE_H_
#include "..\..\LIB\STD_TYPES.h"
#include "..\..\LIB\BIT_MATH.h"
void EXTI_vidInit(void);
void EXTI_vidEnableInterrupt(u8 cpy_u8ExtiNo);
void EXTI_vidDisableInterrupt(u8 cpy_u8ExtiNo);

#endif /* EXTI_INTERFACE_H_ */

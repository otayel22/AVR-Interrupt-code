/*
 * EXTI_private.h
 *
 *  Created on: May 20, 2024
 *      Author: Omar tayel
 */

#ifndef EXTI_PRIVATE_H_
#define EXTI_PRIVATE_H_
#define SREG     *((volatile u8*)(0x5F))
#define MCUCR    *((volatile u8*)(0x55))
#define MCUCSR   *((volatile u8*)(0x54))
#define GICR     *((volatile u8*)(0x5B))
#define GIFR     *((volatile u8*)(0x5A))
#define ISC01    1
#define INT0     6
#endif /* EXTI_PRIVATE_H_ */

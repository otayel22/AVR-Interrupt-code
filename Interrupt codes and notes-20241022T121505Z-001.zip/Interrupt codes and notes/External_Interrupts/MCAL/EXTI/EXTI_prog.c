/*
 * EXTI_prog.c
 *
 *  Created on: May 20, 2024
 *      Author: Omar tayel
 */
#include "EXTI_interface.h"
#include "EXTI_config.h"
#include "EXTI_private.h"
#include "..\..\MCAL\DIO\DIO_interface.h"
#include "..\..\MCAL\DIO\DIO_config.h"
#include "..\..\MCAL\DIO\DIO_private.h"

#include "..\..\LIB\STD_TYPES.h"
#include "..\..\LIB\BIT_MATH.h"

void EXTI_vidInit(void){
	//SENSE CONTROL
	//INT0 -> FALLING EDGE
	SET_BIT(MCUCR,ISC01);
	//Enable Interrupt
	SET_BIT(GICR, INT0);
	// Enable Global interrupt
	SET_BIT(SREG,7);
	//time 2:39
}

void EXTI_vidEnableInterrupt(u8 cpy_u8ExtiNo){
	SET_BIT(GICR, INT0);
}
void EXTI_vidDisableInterrupt(u8 cpy_u8ExtiNo){
	CLR_BIT(GICR, INT0);

}



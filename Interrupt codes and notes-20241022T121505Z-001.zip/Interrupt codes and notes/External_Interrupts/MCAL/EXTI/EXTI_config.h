/*
 * EXTI_config.h
 *
 *  Created on: May 20, 2024
 *      Author: Omar tayel
 */

#ifndef EXTI_CONFIG_H_
#define EXTI_CONFIG_H_



#endif /* EXTI_CONFIG_H_ */



#define     PORTA       0
#define     PORTB       1
#define     PORTC       2
#define     PORTD       3

#define     PIN0        0
#define     PIN1        1
#define     PIN2        2
#define     PIN3        3
#define     PIN4        4
#define     PIN5        5
#define     PIN6        6
#define     PIN7        7

#define     INPUT       0
#define     OUTPUT      1

#define     ALLPORTINPUT 0
#define     ALLPORTOUPUT 255

#define     LOW         0
#define     HIGH        1
#define     ALLPORTHIGH 255
#define     ALLPORTLOW  0

#define     NOPULLUP    0
#define     PULLUP      1

#define     ALLPORTPULLUP 255

#define     ALLPORTNOPULLUP 0
void DIO_voidSetPinDirection(u8 Copy_u8PortName, u8 Copy_u8PinNumber, u8 Copy_u8PinDirection);
void DIO_voidSetPinValue(u8 Copy_u8PortName, u8 Copy_u8PinNumber, u8 Copy_u8PinValue);
void DIO_voidSetPinPullUp(u8 Copy_u8PortName, u8 Copy_u8PinNumber, u8 Copy_u8PullUpState);
void DIO_voidTogPinValue(u8 Copy_u8PortName, u8 Copy_u8PinNumber);
u8   DIO_u8GetPinValue(u8 Copy_u8PortName, u8 Copy_u8PinNumber);
void DIO_voidSetPortSpecificValue(u8 Copy_u8PortName, u8 Copy_PortValue);
void DIO_voidSetPortDirection(u8 Copy_u8PortName, u8 Copy_PortDirection);
void DIO_voidSetPortValue(u8 Copy_u8PortName, u8 Copy_PortValue);
void DIO_voidSetPortPullUp(u8 Copy_u8PortName, u8 Copy_PortStatusValue);
u8 DIO_u8GetPortValue(u8 Copy_u8PortName, u8 Copy_PortValue);





/*
 * main.c
 *
 *  Created on: May 20, 2024
 *      Author: Omar tayel
 */
#include "..\..\MCAL\EXTI\EXTI_interface.h"
#include "..\..\LIB\STD_TYPES.h"
#include "..\..\LIB\BIT_MATH.h"
#include "..\..\MCAL\DIO\DIO_interface.h"
#include "..\..\MCAL\DIO\DIO_config.h"

//time 3:53
void __vector_1(void) __attribute__((signal)); //1 is detected by vector table number -1
void __vector_1(void){

 DIO_voidTogPinValue(PORTA,PIN0);
    
}

int main (){

    DIO_voidSetPinDirection(PORTA ,PIN0,OUTPUT);
    //DIO_voidSetPinValue(PORTA ,PIN0,HIGH);
    DIO_voidSetPinDirection(PORTD, PIN2,INPUT);
    DIO_voidSetPinPullUp(PORTD, PIN2,PULLUP);
    //DIO_voidSetPinValue(DIO_DDRA,PIN0,HIGH);
    EXTI_vidInit();
while(1){
}



}


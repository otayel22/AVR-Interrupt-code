/*Library Inclusion*/
#include "..\..\LIB\STD_TYPES.h"
#include "..\..\LIB\BIT_MATH.h"

/*Lower Layer Inclusion*/

/*Self Layer Inclusion*/

/*Self Files Inclusion*/
#include "SSD_interface.h"
#include "SSD_private.h"
#include "SSD_config.h"
#include "..\..\MCAL\DIO\DIO_interface.h"



void void_SSDDisplayNumber(u8 copy_u8PortName,u8 copy_u8EntryNum,u8 copy_u8LEDStatus){

u8 assignLEDReturn=0;
    if(copy_u8EntryNum<10 && copy_u8LEDStatus<=LED_Anode && copy_u8PortName<=PORTD){
        switch(copy_u8EntryNum){
            case 0:
                assignLEDReturn=0b00111111;
                break;
            case 1:
                assignLEDReturn=0b00000110;
                break;
            case 2:
                assignLEDReturn=0b01011011;
                break;
            case 3:
                assignLEDReturn=0b01001111;
                break;
            case 4:
                assignLEDReturn=0b01100110;
                break;
            case 5:
                assignLEDReturn=0b01101101;
                break;
            case 6:
                assignLEDReturn=0b01111100;
                break;
            case 7:
                assignLEDReturn=0b00000111;
                break;
            case 8:
                assignLEDReturn=0b01111111;
                break;
            case 9:
                assignLEDReturn=0b01101111;
                break;

                }
        switch(copy_u8LEDStatus){
        case  LED_Anode:
            assignLEDReturn=~assignLEDReturn;
            break;
        default:
            break;


        }
        switch(copy_u8PortName){
            case PORTA:
                 DIO_voidSetPortSpecificValue(PORTA,assignLEDReturn);
                 break;
            case PORTB:
                DIO_voidSetPortSpecificValue(PORTB,assignLEDReturn);
                 break;
            case PORTC:
                DIO_voidSetPortSpecificValue(PORTC,assignLEDReturn);
                break;
            case PORTD:
                DIO_voidSetPortSpecificValue(PORTD,assignLEDReturn);
                break;
            default:
                break;
        }
            

        }else{

            //Raise Error
        }



  
}









































